
<?php $__env->startSection('content'); ?>
<div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">                        
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Edit Brand</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>"><i class="icon-home"></i></a></li>                            
                            <li class="breadcrumb-item">Home</li>
                            <li class="breadcrumb-item active">Edit Brand</li>
                        </ul>
                    </div>            
                   
                </div>
            </div>

            <div class="row clearfix">
                
                <div class="col-lg-12">
                    <div class="card">
                        <div class="body">
                        <form class="add-contact-form" method="post" action="<?php echo e(route('brand.update',$brand->id)); ?>" enctype="multipart/form-data">
                             <?php echo csrf_field(); ?>
                             <?php echo method_field('patch'); ?>
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Enter title" name="title" value="<?php echo e($brand->title); ?>" />
                            </div>
                            
                            <select class="form-control show-tick" name="status">
                                <option selected disable>--Select Status--</option>
                                <option value="active" <?php echo e($brand->status == "active" ? "selected" : ""); ?>>Active</option>
                                <option value="inactive" <?php echo e($brand->status == "inactive" ? "selected" : ""); ?>>Inactive</option>
                               
                            </select>
                            <div class="form-group m-t-20 m-b-20">
                                <div class="input-group">
                                    <span class="input-group-btn">
                                        <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                                        <i class="fa fa-picture-o"></i> Choose
                                        </a>
                                    </span>
                                <input id="thumbnail" class="form-control" type="text" name="photo" value=<?php echo e($brand->photo); ?>>
                                </div>
                                <div id="holder" style="margin-top:15px;max-height:100px;"></div>
                            </div>
                            <button type="submit" class="btn btn-block btn-primary  m-t-20">Update Brand</button>
                           </div>
                         </form>
                    </div>
                </div>            
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
$('#lfm').filemanager('image');
</script>>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\9-6-2021(Laravel Project)\cse project\ShantoMulti vandor Ecomarce\multivendor_ecommerce\resources\views/backend/brands/edit.blade.php ENDPATH**/ ?>