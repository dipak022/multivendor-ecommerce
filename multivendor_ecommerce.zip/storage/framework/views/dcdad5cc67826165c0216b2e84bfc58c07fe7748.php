<table class="table table-bordered mb-30">
<thead>
    <tr>
        <th scope="col"><i class="icofont-ui-delete"></i></th>
        <th scope="col">Image</th>
        <th scope="col">Product</th>
        <th scope="col">Unit Price</th>
        <!--
        <th scope="col">Quantity</th>
        -->
        <th scope="col">Favorite List Add To Cart</th>
    </tr>
</thead>
<tbody>
    <?php if(\Gloudemans\Shoppingcart\Facades\Cart::instance('wishlist')->count()): ?>
        <?php $__currentLoopData = \Gloudemans\Shoppingcart\Facades\Cart::instance('wishlist')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row">
                    <i class="icofont-close delete_wishlist" data-id="<?php echo e($item->rowId); ?>"></i>
                </th>
                <td>
                    <img src="<?php echo e($item->model->photo); ?>" alt="<?php echo e($item->model->slug); ?>">
                </td>
                <td>
                    <a href="<?php echo e(route('product.detail',$item->model->slug)); ?>"><?php echo e($item->name); ?></a>
                </td>
                <td><?php echo e(number_format($item->price,2)); ?> TK</td>
                <!--
                <td>
                    <div class="quantity">
                        <input type="number" class="qty-text" id="qty2" step="1" min="1" max="99" name="quantity" value="1">
                    </div>
                </td>
                -->
                <td><a href="javascript:void(0)" data-id="<?php echo e($item->rowId); ?>" class="move-to-cart btn btn-primary btn-sm">Add to Cart</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
          <td colspan="5" class="text-center">You don't have any wishlist product!!</td>
        </tr>
    <?php endif; ?>
</tbody>
</table><?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/frontend/layouts/wishlist.blade.php ENDPATH**/ ?>