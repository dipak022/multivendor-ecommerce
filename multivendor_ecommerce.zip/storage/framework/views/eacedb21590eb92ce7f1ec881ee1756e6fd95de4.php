

<?php $__env->startSection('content'); ?>
 
 <!-- Breadcumb Area -->
 <div class="breadcumb_area">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <h5>My Account</h5>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">My Account</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area -->

    <!-- My Account Area -->
    <section class="my-account-area section_padding_100_50">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-3">
                    <div class="my-account-navigation mb-50">
                       <?php echo $__env->make('frontend.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="col-12 col-lg-9">
                    <div class="my-account-content mb-50">
                        <p>The following addresses will be used on the checkout page by default.</p>

                        <div class="row">
                            <div class="col-12 col-lg-6 mb-5 mb-lg-0">
                                <h6 class="mb-3">Billing Address</h6>
                                <address>
                                    <?php echo e($user->address); ?> <br>
                                    <?php echo e($user->state); ?>,  <?php echo e($user->city); ?> <br>
                                    <?php echo e($user->country); ?> <br>
                                    <?php echo e($user->postcode); ?>

                                </address>
                                <a href="#" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editAddress">Edit Address</a>
                                <!-- Address modal -->
                              
                                <div class="modal fade" id="editAddress" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="false" style="background:rgba(0,0,0,0.5);">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLongTitle">Edit Address</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="<?php echo e(route('billing.address',$user->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                    <div class="form-group">
                                                        <level for="">Address</level>
                                                        <textarea  type="text" class="form-control" name="address" placeholder="Enter your address" ><?php echo e($user->address); ?></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <level for="">Country</level>
                                                        <input type="text" class="form-control" name="country" placeholder="Enter your country" value="<?php echo e($user->country); ?>"></input>
                                                    </div>
                                                    <div class="form-group">
                                                        <level for="">Postcode</level>
                                                        <input  type="number" class="form-control" name="postcode" placeholder="Enter your postcode" value="<?php echo e($user->postcode); ?>"></input>
                                                    </div>
                                                    <div class="form-group">
                                                        <level for="">State</level>
                                                        <input type="text" class="form-control" name="state" placeholder="Enter your state" value="<?php echo e($user->state); ?>"></input>
                                                    </div>
                                                    <div class="form-group">
                                                        <level for="">City</level>
                                                        <input type="text" class="form-control" name="city" placeholder="Enter your city" value="<?php echo e($user->city); ?>"></input>
                                                    </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Update Address</button>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                                 <!-- Modal -->
                            </div>
                            <div class="col-12 col-lg-6">
                                <h6 class="mb-3">Shipping Address</h6>
                                <address>
                                <?php echo e($user->saddress); ?> <br>
                                    <?php echo e($user->sstate); ?>,  <?php echo e($user->scity); ?> <br>
                                    <?php echo e($user->scountry); ?> <br>
                                    <?php echo e($user->spostcode); ?>

                                </address>
                                <a href="#" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#shipingAddress">Edit Address</a>
                                <!-- Shipping Address modal -->
                              
                                <div class="modal fade" id="shipingAddress" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="false" style="background:rgba(0,0,0,0.5);">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLongTitle">Edit Shipping Address</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="<?php echo e(route('shipping.address',$user->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                    <div class="form-group">
                                                        <level for="">Shipping Address</level>
                                                        <textarea type="text" class="form-control" name="saddress" placeholder="Enter your Shipping address" ><?php echo e($user->saddress); ?></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <level for="">Shipping Country</level>
                                                        <input type="text" class="form-control" name="scountry" placeholder="Enter your Shipping country" value="<?php echo e($user->scountry); ?>"></input>
                                                    </div>
                                                    <div class="form-group">
                                                        <level for="">Shipping Postcode</level>
                                                        <input type="number" class="form-control" name="spostcode" placeholder="Enter your Shipping postcode" value="<?php echo e($user->spostcode); ?>"></input>
                                                    </div>
                                                    <div class="form-group">
                                                        <level for="">Shipping State</level>
                                                        <input type="text" class="form-control" name="sstate" placeholder="Enter your Shipping state" value="<?php echo e($user->sstate); ?>"></input>
                                                    </div>
                                                    <div class="form-group">
                                                        <level for="">Shipping City</level>
                                                        <input type="text" class="form-control" name="scity" placeholder="Enter your Shipping city" value="<?php echo e($user->scity); ?>"></input>
                                                    </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Update Shipping Address</button>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                                 <!-- Modal -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- My Account Area -->

<?php $__env->stopSection(); ?>   
<?php $__env->startSection('styles'); ?>
<style>
.footer_area{
    z-index:-1;
}
</style>

<?php $__env->stopSection(); ?>  

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/frontend/user/address.blade.php ENDPATH**/ ?>