
<!-- Top Header Area -->
<div class="top-header-area">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-6">
                <div class="welcome-note">
                    <span class="popover--text" data-toggle="popover" data-content="Welcome to Bigshop ecommerce template."><i class="icofont-info-square"></i></span>
                    <span class="text"><?php echo e(\App\Models\Setting::value('meta_description')); ?></span>
                </div>
            </div>
            <div class="col-6">
                <div class="language-currency-dropdown d-flex align-items-center justify-content-end">
                    <!-- Language Dropdown -->
                    <div class="language-dropdown">
                        <div class="dropdown">
                            <a class="btn btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                English
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu1">
                                <a class="dropdown-item" href="#">Bangla</a>
                            </div>
                        </div>
                    </div>

                    <!-- Currency Dropdown -->
                    <div class="currency-dropdown">
                        <div class="dropdown">
                            <a class="btn btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            ৳ BDT
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
                                <a class="dropdown-item" href="#">৳ BDT</a>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Menu -->
<div class="bigshop-main-menu">
    <div class="container">
        <div class="classy-nav-container breakpoint-off">
            <nav class="classy-navbar" id="bigshopNav">

                <!-- Nav Brand -->
                <a href="<?php echo e(route('home')); ?>" class="nav-brand"><img src="<?php echo e(\App\Models\Setting::value('logo')); ?>" style="height: 40px;width: 70px;" alt="logo"></a>

                <!-- Toggler -->
                <div class="classy-navbar-toggler">
                    <span class="navbarToggler"><span></span><span></span><span></span></span>
                </div>

                <!-- Menu -->
                <div class="classy-menu">
                    <!-- Close -->
                    <div class="classycloseIcon">
                        <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                    </div>

                    <!-- Nav -->
                    <div class="classynav">
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>">Home</a>
                                
                            </li>
                            <li><a href="<?php echo e(route('shop')); ?>">Shop</a>
                                
                            </li>
                            <li><a href="#">Pages</a>
                                <div class="megamenu">
                                    <ul class="single-mega cn-col-4">
                                        <li><a href="about-us.html">- About Us</a></li>
                                        <li><a href="faq.html">- FAQ</a></li>
                                        <li><a href="contact.html">- Contact</a></li>
                                        <li><a href="login.html">- Login &amp; Register</a></li>
                                        <li><a href="404.html">- 404</a></li>
                                        <li><a href="500.html">- 500</a></li>
                                    </ul>
                                    <ul class="single-mega cn-col-4">
                                        <li><a href="my-account.html">- Dashboard</a></li>
                                        <li><a href="order-list.html">- Orders</a></li>
                                        <li><a href="downloads.html">- Downloads</a></li>
                                        <li><a href="addresses.html">- Addresses</a></li>
                                        <li><a href="account-details.html">- Account Details</a></li>
                                        <li><a href="coming-soon.html">- Coming Soon</a></li>
                                    </ul>
                                    <div class="single-mega cn-col-2">
                                        <div class="megamenu-slides owl-carousel">
                                            <a href="shop-grid-left-sidebar.html">
                                                <img src="<?php echo e(asset('frontend/')); ?>/img/bg-img/mega-slide-2.jpg" alt="">
                                            </a>
                                            <a href="shop-list-left-sidebar.html">
                                                <img src="<?php echo e(asset('frontend/')); ?>/img/bg-img/mega-slide-1.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li><a href="#">Blog</a>
                                <ul class="dropdown">
                                    <li><a href="blog-with-left-sidebar.html">Blog Left Sidebar</a></li>
                                    <li><a href="blog-with-right-sidebar.html">Blog Right Sidebar</a></li>
                                    <li><a href="blog-with-no-sidebar.html">Blog No Sidebar</a></li>
                                    <li><a href="single-blog.html">Single Blog</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Elements</a>
                                <div class="megamenu">
                                    <ul class="single-mega cn-col-4">
                                        <li><a href="accordian.html">- Accordions</a></li>
                                        <li><a href="alerts.html">- Alerts</a></li>
                                        <li><a href="badges.html">- Badges</a></li>
                                        <li><a href="blockquotes.html">- Blockquotes</a></li>
                                    </ul>
                                    <ul class="single-mega cn-col-4">
                                        <li><a href="breadcrumb.html">- Breadcrumbs</a></li>
                                        <li><a href="buttons.html">- Buttons</a></li>
                                        <li><a href="forms.html">- Forms</a></li>
                                        <li><a href="gallery.html">- Gallery</a></li>
                                    </ul>
                                    <ul class="single-mega cn-col-4">
                                        <li><a href="heading.html">- Headings</a></li>
                                        <li><a href="icon-fontawesome.html">- Icon FontAwesome</a></li>
                                        <li><a href="icon-icofont.html">- Icon Ico Font</a></li>
                                        <li><a href="labels.html">- Labels</a></li>
                                    </ul>
                                    <ul class="single-mega cn-col-4">
                                        <li><a href="modals.html">- Modals</a></li>
                                        <li><a href="pagination.html">- Pagination</a></li>
                                        <li><a href="progress-bars.html">- Progress Bars</a></li>
                                        <li><a href="tables.html">- Tables</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li><a href="contact.html">Contact</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Hero Meta -->
                <div class="hero_meta_area ml-auto d-flex align-items-center justify-content-end">
                    <!-- Search -->
                    <div class="search-area">
                        <div class="search-btn"><i class="icofont-search"></i></div>
                        <!-- Form -->
                       <form action="<?php echo e(route('search')); ?>" method="GET">
                       <div class="search-form">
                            <input type="search" id="search_text" name="query" class="form-control" placeholder="Search">
                            <input type="submit" class="d-none" value="Send">
                        </div>
                       </form>
                    </div>

                    <!-- Wishlist -->
                    <div class="wishlist-area">
                        <a href="<?php echo e(route('wishlist')); ?>" class="wishlist-btn" id="wishlist_count"><i class="icofont-heart"></i>(<?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::instance('wishlist')->count()); ?>)</a>
                    </div>

                    <!-- Cart -->
                    <div class="cart-area">
                        <div class="cart--btn"><i class="icofont-cart"></i> <span class="cart_quantity" id="cart-counter"><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::instance('shopping')->count()); ?></span></div>

                        <!-- Cart Dropdown Content -->
                        <div class="cart-dropdown-content">
                            <ul class="cart-list">
                                <?php $__currentLoopData = \Gloudemans\Shoppingcart\Facades\Cart::instance('shopping')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="cart-item-desc">
                                            <a href="#" class="image">
                                                <img src="<?php echo e($item->model->photo); ?>" class="cart-thumb" alt="">
                                            </a>
                                            <div>
                                                <a href="<?php echo e(route('product.detail',$item->model->slug)); ?>"><?php echo e($item->name); ?></a>
                                                <p><?php echo e($item->qty); ?> x - <span class="price"><?php echo e(number_format($item->price,2)); ?> TK</span></p>
                                            </div>
                                        </div>
                                        <span class="dropdown-product-remove cart_delete" data-id="<?php echo e($item->rowId); ?>"><i class="icofont-bin"></i></span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </ul>
                            <div class="cart-pricing my-4">
                                <ul>
                                    <li>
                                        <span>Sub Total:</span>
                                        <span><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::subtotal()); ?> TK</span>
                                    </li>
                                    <!--
                                    <li>
                                        <span>Shipping:</span>
                                        <span>$30.00</span>
                                    </li>
                                    -->
                                    <li>
                                        <span>Total:</span>
                                        <?php if(session()->has('coupon')): ?>
                                        <!--
                                        <span><?php echo e(filter_var(\Gloudemans\Shoppingcart\Facades\Cart::subtotal(),FILTER_SANITIZE_NUMBER_INT) - session('coupon')['value']); ?> TK</span>
                                        <span><?php echo e((float) str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::subtotal()) - session('coupon')['value']); ?> TK</span>
                                        -->
                                        <span><?php echo e(number_format((float) str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::subtotal()) - session('coupon')['value'],2)); ?> TK</span>
                                        <?php else: ?>
                                        <span><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::subtotal()); ?> TK</span>
                                        <?php endif; ?>
                                    </li>
                                </ul>
                            </div>
                            <div class="cart-box d-flex">
                                <a href="<?php echo e(route('cart')); ?>" class="btn btn-sm btn-primary" style="margin-right:5px;">View Cart</a>
                                <a href="<?php echo e(route('checkout1')); ?>" class="btn btn-sm btn-secondary float-right">Checkout</a>
                            </div>
                        </div>
                    </div>

                    <!-- Account -->
                    <div class="account-area">
                        <div class="user-thumbnail">
                            <?php if(Auth::check()): ?>
                            <img src="<?php echo e(auth()->user()->photo); ?>" alt="">
                            <?php else: ?>
                            <img src="<?php echo e(Helpers::UserDefaultImage()); ?>" alt="">
                            <?php endif; ?>
                            
                        </div>
                        <ul class="user-meta-dropdown">
                            <?php if(auth()->guard()->check()): ?>
                            <?php 
                                $first_name = explode(' ',auth()->user()->full_name);
                            ?>
                            <li class="user-title"><span>Welcome,</span> <?php echo e($first_name[0]); ?></li>
                            <li><a href="<?php echo e(route('user.dashboard')); ?>">My Account</a></li>
                            <li><a href="<?php echo e(route('user.order')); ?>">Orders List</a></li>
                            <li><a href="<?php echo e(route('wishlist')); ?>">Wishlist</a></li>
                            <li><a href="<?php echo e(route('user.logout')); ?>"><i class="icofont-logout"></i> Logout</a></li>
                            <?php else: ?>
                            <li><a href="<?php echo e(route('user.auth')); ?>">Login & Register</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</div>
    <?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>