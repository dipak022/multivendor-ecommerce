<meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>MultiVendor E-commerce </title>

    <!-- Favicon  -->
    <link rel="icon" href="<?php echo e(asset('frontend')); ?>/img/core-img/favicon.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/')); ?>/style.css">
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">

    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">

    <?php echo $__env->yieldContent('styles'); ?><?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/frontend/layouts/head.blade.php ENDPATH**/ ?>