<title>Multivendor Ecomearce</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="description" content="Lucid Bootstrap 4.1.1 Admin Template">
<meta name="author" content="WrapTheme, design by: ThemeMakker.com">

<link rel="icon" href="favicon.ico" type="image/x-icon">
<!-- VENDOR CSS -->
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/assets/vendor/font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/assets/vendor/summernote/dist/summernote.css"/>

<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/assets/vendor/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/assets/vendor/chartist/css/chartist.min.css">
<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/assets/vendor/chartist-plugin-tooltip/chartist-plugin-tooltip.css">
<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/assets/vendor/toastr/toastr.min.css">
<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap-switch-button@1.1.0/css/bootstrap-switch-button.min.css" rel="stylesheet">



<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/assets/vendor/sweetalert/sweetalert.css"/>
<!-- MAIN CSS -->
<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/asset/css/main.css">
<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/asset/css/color_skins.css">

<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/asset/css/main.css">
<link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/asset/css/color_skins.css">
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">


<?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/backend/layouts/header.blade.php ENDPATH**/ ?>