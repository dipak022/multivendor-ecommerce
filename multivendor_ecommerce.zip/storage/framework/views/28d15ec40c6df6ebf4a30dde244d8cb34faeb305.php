

<?php $__env->startSection('content'); ?>
    <!-- Breadcumb Area -->
    <div class="breadcumb_area">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <h5>Checkout</h5>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active">Checkout</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcumb Area -->

    <!-- Checkout Step Area -->
    <div class="checkout_steps_area">
        <a class="complated" href="checkout-2.html"><i class="icofont-check-circled"></i> Billing</a>
        <a class="complated" href="checkout-3.html"><i class="icofont-check-circled"></i> Shipping</a>
        <a class="complated" href="checkout-4.html"><i class="icofont-check-circled"></i> Payment</a>
        <a class="active" href="checkout-5.html"><i class="icofont-check-circled"></i> Review</a>
    </div>
    <!-- Checkout Step Area -->

    <!-- Checkout Area -->
    <div class="checkout_area section_padding_100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="checkout_details_area clearfix">
                        <h5 class="mb-30">Review Your Order</h5>

                        <div class="cart-table">
                            <div class="table-responsive">
                                <table class="table table-bordered mb-30">
                                    <thead>
                                        <tr>
                                            <th scope="col">Image</th>
                                            <th scope="col">Product</th>
                                            <th scope="col">Unit Price</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = \Gloudemans\Shoppingcart\Facades\Cart::instance('shopping')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                               
                                                <td>
                                                    <img src="<?php echo e($item->model->photo); ?>" alt="Product">
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('product.detail',$item->model->slug)); ?>"><?php echo e($item->name); ?></a>
                                                </td>
                                                <td><?php echo e(number_format($item->price,2)); ?> TK</td>
                                                <td>
                                                <?php echo e($item->qty); ?>

                                                </td>
                                                <td><?php echo e(number_format($item->price*$item->qty,2)); ?> TK</td>
                                            </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-7 ml-auto">
                    <div class="cart-total-area">
                        <h5 class="mb-3">Cart Totals</h5>
                        <div class="table-responsive">
                            <table class="table mb-0">
                                <tbody>
                                    <tr>
                                        <td>Sub Total</td>
                                        <td><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::subtotal()); ?>TK</td>
                                    </tr>
                                    <tr>
                                        <td>Shipping</td>
                                        <td><?php echo e(number_format(\Illuminate\Support\Facades\Session::get('checkout')[0]['delivery_charge'],2)); ?> TK</td>
                                    </tr>
                                   
                                       
                                       
                                    <?php if(\Illuminate\Support\Facades\Session::has('coupon')): ?>
                                    <tr>
                                        <td>Coupon Discount</td>
                                        <td><?php echo e(number_format((float) str_replace(',','',\Illuminate\Support\Facades\Session::get('coupon')['value']),2)); ?> TK</td>
                                    </tr>
                                    <?php else: ?>

                                    <?php endif; ?>
                                   
                                    <td>Total</td>
                                    <?php if(\Illuminate\Support\Facades\Session::has('coupon') && \Illuminate\Support\Facades\Session::has('checkout')): ?>
                                    <td><?php echo e(number_format((float) str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::subtotal()) +
                                         ((float) \Illuminate\Support\Facades\Session::get('checkout')[0]['delivery_charge']) - 
                                         ((float)\Illuminate\Support\Facades\Session::get('coupon')['value']),2)); ?> TK</td>
                                   
                                    <?php elseif(\Illuminate\Support\Facades\Session::has('checkout')): ?>
                                    <td><?php echo e(number_format((float) str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::subtotal()) + \Illuminate\Support\Facades\Session::get('checkout')[0]['delivery_charge'],2)); ?> TK</td>
                                    <?php elseif(\Illuminate\Support\Facades\Session::has('coupon')): ?>
                                    <td><?php echo e(number_format((float) str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::subtotal()) - session('coupon')['value'],2)); ?> TK</td>
                                    <?php else: ?>
                                    <td><?php echo e(number_format((float) str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::subtotal()),2)); ?> TK</td>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="checkout_pagination d-flex justify-content-end mt-3">
                            <a href="checkout-4.html" class="btn btn-primary mt-2 ml-2 d-none d-sm-inline-block">Go Back</a>
                            <a href="<?php echo e(route('checkout.store')); ?>" class="btn btn-primary mt-2 ml-2">Confirm</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Checkout Area End -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/frontend/pages/checkout/checkout4.blade.php ENDPATH**/ ?>