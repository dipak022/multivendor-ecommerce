
<!-- Single Product -->
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-9 col-sm-6 col-md-4 col-lg-3">
            <div class="single-product-area mb-30">
                <?php
                    $photo = explode(',',$item->photo)
                ?>
                <div class="product_image">
                    <!-- Product Image -->
                    <img class="normal_img" src="<?php echo e($photo[0]); ?>" alt="<?php echo e($item->title); ?>">
                    <img class="hover_img" src="<?php echo e($photo[0]); ?>" alt="<?php echo e($item->title); ?>">

                    <!-- Product Badge -->
                    <div class="product_badge">
                        <span><?php echo e($item->conditions); ?></span>
                    </div>

                    <!-- Wishlist -->
                    <div class="product_wishlist">
                        <a href="javascript:void(0)" class="add_to_wishlist" data-quantity="1" data-id="<?php echo e($item->id); ?>" id="add_to_wishlist_<?php echo e($item->id); ?>"  ><i class="icofont-heart"></i></a>
                    </div>

                    <!-- Compare -->
                    <div class="product_compare">
                        <a href="compare.html"><i class="icofont-exchange"></i></a>
                    </div>
                </div>

                <!-- Product Description -->
                <div class="product_description">
                    <!-- Add to cart -->
                    <div class="product_add_to_cart">
                        <a href="#" data-quantity="1" data-product-id="<?php echo e($item->id); ?>" class="add_to_cart" id="add_to_cart<?php echo e($item->id); ?>"><i class="icofont-shopping-cart"></i> Add to Cart</a>
                    </div>

                    <!-- Quick View -->
                    <div class="product_quick_view">
                        <a href="#" data-toggle="modal" data-target="#quickview"><i class="icofont-eye-alt"></i> Quick View</a>
                    </div>

                    <p class="brand_name"><?php echo e(\App\Models\Brand::where('id',$item->brand_id)->value('title')); ?></p>
                    <a href="<?php echo e(route('product.detail',$item->slug)); ?>"><?php echo e(ucfirst($item->title)); ?></a>
                    <h6 class="product-price"><?php echo e(number_format($item->offer_price,2)); ?> TK <span><del class="text-danger"><?php echo e(number_format($item->price,2)); ?> TK</del></span></h6>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- Single Product -->
<?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/frontend/layouts/single-product.blade.php ENDPATH**/ ?>