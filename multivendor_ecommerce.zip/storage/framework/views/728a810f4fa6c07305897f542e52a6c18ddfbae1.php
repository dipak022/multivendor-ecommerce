<ul>
    <li class="<?php echo e(\Request::is('user/dashboard') ? 'active' : ''); ?>"><a href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a></li>
    <li class="<?php echo e(\Request::is('user/order') ? 'active' : ''); ?>"><a href="<?php echo e(route('user.order')); ?>">Orders</a></li>
    <li class="<?php echo e(\Request::is('user/address') ? 'active' : ''); ?>"><a href="<?php echo e(route('user.address')); ?>">Addresses</a></li>
    <li class="<?php echo e(\Request::is('user/account-detail') ? 'active' : ''); ?>"><a href="account-detail">Account Details</a></li>
    <li><a href="<?php echo e(route('user.logout')); ?>">Logout</a></li>
</ul><?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/frontend/user/sidebar.blade.php ENDPATH**/ ?>