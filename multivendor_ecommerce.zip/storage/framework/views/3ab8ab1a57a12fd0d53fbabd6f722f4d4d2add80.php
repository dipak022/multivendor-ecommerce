
<!doctype html>
<html lang="en">

<head>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="theme-cyan">


<div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30"><img src="<?php echo e(asset('backend/assets/')); ?>/loader.gif" width="48" height="48" alt="Lucid"></div>
        <p>Please wait...</p>        
    </div>
</div>


<div id="wrapper">
<?php echo $__env->make('backend.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('backend.layouts.sideber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

 <?php echo $__env->yieldContent('content'); ?>
    


</div>
</body>
<?php echo $__env->make('backend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH H:\9-6-2021(Laravel Project)\cse project\ShantoMulti vandor Ecomarce\multivendor_ecommerce\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>