
<?php $__env->startSection('content'); ?>
<div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">                        
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Dashboard</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>"><i class="icon-home"></i></a></li>                            
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ul>
                    </div>            
                   
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card overflowhidden number-chart">
                        <div class="body">
                            <div class="number">
                                <h6>Total Category</h6>
                                <span><?php echo e(\App\Models\Category::where('status','active')->count()); ?> Categorys</span>
                            </div>
                           
                        </div>
                        <div class="sparkline" data-type="line" data-spot-Radius="0" data-offset="90" data-width="100%" data-height="50px"
                        data-line-Width="1" data-line-Color="#f79647" data-fill-Color="#fac091">1,4,1,3,7,1</div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card overflowhidden number-chart">
                        <div class="body">
                            <div class="number">
                                 <h6>Total Product</h6>
                                <span><?php echo e(\App\Models\Product::where('status','active')->count()); ?> Products</span>
                            </div>
                         
                        </div>
                        <div class="sparkline" data-type="line" data-spot-Radius="0" data-offset="90" data-width="100%" data-height="50px"
                        data-line-Width="1" data-line-Color="#604a7b" data-fill-Color="#a092b0">1,4,2,3,6,2</div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card overflowhidden number-chart">
                        <div class="body">
                            <div class="number">
                            <h6>New Customer</h6>
                                <span><?php echo e(\App\Models\User::where('status','active')->count()); ?> Products</span>
                            </div>
                           
                        </div>
                        <div class="sparkline" data-type="line" data-spot-Radius="0" data-offset="90" data-width="100%" data-height="50px"
                        data-line-Width="1" data-line-Color="#4aacc5" data-fill-Color="#92cddc">1,4,2,3,1,5</div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card overflowhidden number-chart">
                        <div class="body">
                            <div class="number">
                                <h6>Profit</h6>
                                <span>0 TK</span>
                            </div>
                           
                        </div>
                        <div class="sparkline" data-type="line" data-spot-Radius="0" data-offset="90" data-width="100%" data-height="50px"
                        data-line-Width="1" data-line-Color="#4f81bc" data-fill-Color="#95b3d7">1,3,5,1,4,2</div>
                    </div>
                </div>
            </div>

        
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">                        
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Order List</h2>
                       
                    </div>            
                    <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                        <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                            <h3 > Total Order :<?php echo e(\App\Models\Order::count()); ?> </h3>
                        </div>
                        <div class="inlineblock text-center m-r-15 m-l-15 hidden-sm">
                        <a class="btn btn-success" href="<?php echo e(route('banner.create')); ?>">View All Order</a>
                        </div>
                    </div>
                </div>
            
            
            <div class="row clearfix">
                
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>Order Information List </h2>                            
                        </div>
                        <div class="body">
						<div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                <thead>
                                    <tr>
                                        <th>S.N.</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Payment Method</th>
                                        <th>Payment Status</th>
                                        <th>Total</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                               
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->payment_method); ?></td>
                                        <td>
                                            <?php if($item->payment_status === 'paid'): ?>
                                            <span class="badge badge-success"><?php echo e($item->payment_status); ?></span>
                                            <?php else: ?>
                                            <span class="badge badge-dander"><?php echo e($item->payment_status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($item->total_amount); ?></td>
                                        <td>
                                            <?php if($item->condition === 'pending'): ?>
                                            <span class="badge badge-success"><?php echo e($item->condition); ?></span>
                                            <?php elseif($item->condition === 'processing'): ?>
                                            <span class="badge badge-primary"><?php echo e($item->condition); ?></span>
                                            <?php elseif($item->condition === 'delivered'): ?>
                                            <span class="badge badge-info"><?php echo e($item->condition); ?></span>
                                            <?php else: ?>
                                            <span class="badge badge-dander"><?php echo e($item->condition); ?></span>
                                            <?php endif; ?>
                                        </td>
                                     
                                        <td>
                                            <a type="button" href="<?php echo e(route('banner.edit',$item->id)); ?>" class="btn btn-info" title="Edit"><i class="float-left fa fa-eye"></i></a>
                                            <form class="float-left px-2" action="<?php echo e(route('banner.destroy',$item->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?> 
                                                <?php echo method_field('delete'); ?>
                                                <a type="button" data-type="confirm" class="dltBtn btn btn-danger js-sweetalert " title="Delete"><i class="float-left fa fa-trash-o"></i></a>

                                            </form>
                                            
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                   
                                </tbody>
                            </table>
							</div>
                        </div>
                    </div>
                </div>
            </div>

           

        </div>
    </div>
       
            

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/backend/index.blade.php ENDPATH**/ ?>