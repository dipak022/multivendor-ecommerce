

<div class="col-12">
    <div class="cart-table">
        <div class="table-responsive" >
        <table class="table table-bordered mb-30">
            <thead>
                <tr>
                    <th scope="col"><i class="icofont-ui-delete"></i></th>
                    <th scope="col">Image</th>
                    <th scope="col">Product</th>
                    <th scope="col">Unit Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = \Gloudemans\Shoppingcart\Facades\Cart::instance('shopping')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">
                            <i class="icofont-close cart_delete" data-id="<?php echo e($item->rowId); ?>"></i>
                        </th>
                        <td>
                            <img src="<?php echo e($item->model->photo); ?>" alt="<?php echo e($item->model->slug); ?>">
                        </td>
                        <td>
                            <a href="<?php echo e(route('product.detail',$item->model->slug)); ?>"><?php echo e($item->name); ?></a>
                        </td>
                        <td><?php echo e(number_format($item->price,2)); ?> TK</td>
                        <td>
                            <div class="quantity">
                                <input type="number" class="qty-text" data-id="<?php echo e($item->rowId); ?>" id="qty-input-<?php echo e($item->rowId); ?>" step="1" min="1" max="99" name="quantity" value="<?php echo e($item->qty); ?>">
                                <input type="hidden"  data-id="<?php echo e($item->rowId); ?>" data-product-quantity="<?php echo e($item->model->strock); ?>" id="updates-cart-<?php echo e($item->rowId); ?>" >
                            </div>
                        </td>
                        <td><?php echo e(number_format($item->price*$item->qty,2)); ?> TK</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
            </table>
        </div>
    </div>
</div>

<div class="col-12 col-lg-6">
    <div class="cart-apply-coupon mb-30">
        <h6>Have a Coupon?</h6>
        <p>Enter your coupon code here &amp; get awesome discounts!</p>
        <!-- Form -->
        <div class="coupon-form" >
            <form action="<?php echo e(route('coupon.add')); ?>" method="post" id="coupon-form">
                <?php echo csrf_field(); ?>
                <input type="text" class="form-control" name="code" placeholder="Enter Your Coupon Code">
                <button type="submit" class="btn btn-primary coupon-btn" >Apply Coupon</button>
            </form>
        </div>
    </div>
</div>

<div class="col-12 col-lg-5">
    <div class="cart-total-area mb-30">
        <h5 class="mb-3">Cart Information</h5>
        <div class="table-responsive">
            <table class="table mb-3">
                <tbody>
                    <tr>
                        <td>Sub Total</td>
                        <td><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::subtotal()); ?>TK</td>
                    </tr>
                    <tr>
                        <td>Save Amount</td>
                        <td><?php if(Illuminate\Support\Facades\Session::has('coupon')): ?>
                            <?php echo e(number_format(\Illuminate\Support\Facades\Session::get('coupon')['value'])); ?> TK 
                            <?php else: ?> 
                            0
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>VAT 
                           
                        </td>
                            <?php if(Illuminate\Support\Facades\Session::has('coupon')): ?>
                        <td><?php echo e(number_format((float) str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::subtotal()) - session('coupon')['value'],2)); ?> TK</td>
                        <?php else: ?>

                        <?php endif; ?>
                    </tr>
                    <tr>
                        <td>Total</td>
                        <?php if(Illuminate\Support\Facades\Session::has('coupon')): ?>
                        <td><?php echo e(number_format((float) str_replace(',','',\Gloudemans\Shoppingcart\Facades\Cart::subtotal()) - session('coupon')['value'],2)); ?> TK</td>
                        <?php else: ?>
                        <td><?php echo e(\Gloudemans\Shoppingcart\Facades\Cart::subtotal()); ?>TK</td>
                        <?php endif; ?>
                    </tr>
                </tbody>
            </table>
        </div>
        <a href="<?php echo e(route('checkout1')); ?>" class="btn btn-primary d-block">Proceed To Checkout</a>
    </div>
</div>



<?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/frontend/layouts/cart-list.blade.php ENDPATH**/ ?>