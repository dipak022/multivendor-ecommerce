
<?php $__env->startSection('content'); ?>
 
<div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">                        
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Product List</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>                            
                            <li class="breadcrumb-item">Product</li>
                            <li class="breadcrumb-item active">Product Information</li>
                        </ul>
                    </div>            
                   
                </div>
            </div>
            
            <div class="row clearfix">
                
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e($product->title); ?> </h2>    
                            <br/>
                            <div class="row">
                                <div class="col-md-6">
                                    <form action="<?php echo e(route('product.attribute',$product->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                            <div id="example-1" class="content" data-mfield-options='{"section": ".group","btnAdd":"#btnAdd-1","btnRemove":".btnRemove"}'>
                                            <div class="row">
                                                <div class="col-md-12"><button type="button" id="btnAdd-1" class="btn btn-primary">Add </button></div>
                                            </div>
                                            <div class="row group">
                                                <div class="col-md-2">
                                                    <level> Size</level>
                                                    <input class="form-control form-control-sm" placeholder="size" name="size[]" type="text">
                                                </div>
                                                <div class="col-md-3">
                                                <level> Original price</level>
                                                    <input class="form-control form-control-sm" placeholder="Original price" name="original_price[]" type="text">
                                                </div>
                                                <div class="col-md-3">
                                                <level> Offer price</level>
                                                    <input class="form-control form-control-sm" placeholder="Offer price" name="offer_price[]" type="text">
                                                </div>
                                                <div class="col-md-2">
                                                <level> Stock</level>
                                                    <input class="form-control form-control-sm" placeholder="Stock" name="stock[]" type="number">
                                                </div>
                                                
                                                <div class="col-md-2">
                                                <level> Delete</level>
                                                </br>
                                                    <button type="button" class="btn btn-sm btn-danger btnRemove"><i class="float-left fa fa-trash-o"></i></button>
                                                </div>
                                            </div>
                                            
                                           
                                        </div>
                                        <br/>
                                        <button class="btn btn-success" type="submit">Submit</button>

                                    </form>
                              

                                </div>
                                <div class="col-md-6">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>S.N.</th>
                                            <th>Size</th>
                                            <th>Orginal</th>
                                            <th>Offer</th>
                                            <th>Stock</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($productattr)>0): ?>
                                            <?php $__currentLoopData = $productattr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($item->size); ?></td>
                                                <td><?php echo e($item->original_price); ?></td>
                                                <td><?php echo e($item->offer_price); ?></td>
                                                <td><?php echo e($item->stock); ?></td>
                                                <td>
                                                    <form class="float-left px-2" action="<?php echo e(route('product.attribute.destroy',$item->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?> 
                                                        <?php echo method_field('delete'); ?>
                                                        <a type="button" data-type="confirm" class="dltBtn btn btn-danger js-sweetalert " title="Delete"><i class="float-left fa fa-trash-o"></i></a>
                                                    </form>
                                                 </td>
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>    
                                    </tbody>
                                </table>
                                </div>
                            </div>                        
                        </div>
                        <div class="body">
						<div class="table-responsive">
                          
							</div>
                        </div>
                    </div>
                </div>
            </div>

           

        </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('backend/asset/js/jquery.multifield.min.js')); ?>"></script>
<script>
$('#example-1').multifield();
</script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
    });
    $('.dltBtn').click(function(e){
       
        var form = $(this).closest('form');
        var dataId = $(this).data('id');
        e.preventDefault();
        Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
        if (result.isConfirmed) {
            form.submit();
            Swal.fire(
            'Deleted!',
            'Your file has been deleted.',
            'success'
            )
        }
        })
        
        

    });

</script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\9-6-2021(Laravel Project)\cse project\Multi vandor Ecomarce\multivendor_ecommerce\resources\views/backend/products/product-attribute.blade.php ENDPATH**/ ?>