
<!-- Javascript -->
<script src="<?php echo e(asset('backend/')); ?>/asset/bundles/libscripts.bundle.js"></script>    
<script src="<?php echo e(asset('backend/')); ?>/asset/bundles/vendorscripts.bundle.js"></script>

<script src="<?php echo e(asset('backend/')); ?>/asset/bundles/chartist.bundle.js"></script>
<script src="<?php echo e(asset('backend/')); ?>/asset/bundles/knob.bundle.js"></script> <!-- Jquery Knob-->
<script src="<?php echo e(asset('backend/')); ?>/assets/vendor/toastr/toastr.js"></script>


<script src="<?php echo e(asset('backend/')); ?>/asset/bundles/datatablescripts.bundle.js"></script>
<script src="<?php echo e(asset('backend/')); ?>/assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('backend/')); ?>/assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('backend/')); ?>/assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js"></script>
<script src="<?php echo e(asset('backend/')); ?>/assets/vendor/jquery-datatable/buttons/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('backend/')); ?>/assets/vendor/jquery-datatable/buttons/buttons.print.min.js"></script>
<script src="<?php echo e(asset('backend/')); ?>/assets/vendor/sweetalert/sweetalert.min.js"></script> 



<script src="<?php echo e(asset('backend/')); ?>/asset/bundles/mainscripts.bundle.js"></script>
<script src="<?php echo e(asset('backend/')); ?>/asset/js/pages/tables/jquery-datatable.js"></script>

<script src="<?php echo e(asset('backend/')); ?>/asset/js/index.js"></script>
<script src="<?php echo e(asset('backend/')); ?>/assets/vendor/summernote/dist/summernote.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap-switch-button@1.1.0/dist/bootstrap-switch-button.min.js"></script>

<?php echo $__env->yieldContent('scripts'); ?>

<script>
    jQuery(document).ready(function() {

        $('.summernote').summernote({
            height: 350, // set editor height
            minHeight: null, // set minimum height of editor
            maxHeight: null, // set maximum height of editor
            focus: false, // set focus to editable area after initializing summernote
            popover: { image: [], link: [], air: [] }
        });

        $('.inline-editor').summernote({
            airMode: true
        });

    });

    window.edit = function() {
            $(".click2edit").summernote()
        },
        
    window.save = function() {
        $(".click2edit").summernote('destroy');
    }
</script>

<script>
    <?php if(Session::has('message')): ?>
            var type="<?php echo e(Session::get('alert-type','info')); ?>"

    
            switch(type){
                case 'info':
                    toastr.info("<?php echo e(Session::get('message')); ?>");
                    break;
            case 'success':
                toastr.success("<?php echo e(Session::get('message')); ?>");
                break;
            case 'warning':
                toastr.warning("<?php echo e(Session::get('message')); ?>");
                break;
            case 'error':
                    toastr.error("<?php echo e(Session::get('message')); ?>");
                    break;
            }
    <?php endif; ?>
</script>











<?php /**PATH H:\9-6-2021(Laravel Project)\cse project\ShantoMulti vandor Ecomarce\multivendor_ecommerce\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>